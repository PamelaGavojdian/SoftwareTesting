package edu.depaul.se433;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.fail;

public class NameFormatterTest {

  
  @Test
  @DisplayName("Test name Abcd less than 20")
  void T1() {
	  String name = NameFormatter.format("Abcd");
      assertEquals("Abcd", name);
  }
  @Test
  @DisplayName ("Testing string with length 2 which is smallest allowed length for the program")
  void testValid1(){
       assertEquals("ab", NameFormatter.format("ab"));
  }

  @Test
  @DisplayName ("Testing string with length 1 which is invalid")
  void testInvalid1(){
       assertThrows(IllegalArgumentException.class, () -> NameFormatter.format("a"));
  }
  
  @Test
  @DisplayName ("Testing string with one invalid character")
  void testInvalid2(){
	  String name = NameFormatter.format("abcde?fbterbhsdtaerq");
	  fail("abcde?fbterbhsdtaerq has a special character which is invalid");
  }
  
  @Test
  @DisplayName ("Testing string with just invalid characters")
  void testInvalid12(){
	  String name = NameFormatter.format("@?#$%*");
	  assertThrows(IllegalArgumentException.class, () -> NameFormatter.format("@?#$%*"));
	  fail("@?#$%* are special character which is invalid");
  }
  
  @Test
  @DisplayName ("Testing string with length 31 which is invalid")
  void testInvalid3(){
	  assertThrows(IllegalArgumentException.class, () -> NameFormatter.format("abcdefghijklmnopqrstuvwxyzabcde"));
  }
  
  @Test
  @DisplayName ("Testing string with length 30 which is valid but replaced with *")
  void testInvalid4(){
	  assertEquals("abcdefghijklmnopqrst***", NameFormatter.format("abcdefghijklmnopqrstuvwxyzabcd"));
  }
  
  @Test
  @DisplayName ("Testing string with length 29 which is valid but replaced with *")
  void testInvalid5(){
	  assertEquals("abcdefghijklmnopqrst***", NameFormatter.format("abcdefghijklmnopqrstuvwxyzabc"));
  }
  
  @Test
  @DisplayName ("Testing string with length 21 which is valid but replaced with *")
  void testInvalid15(){
	  assertEquals("abcdefghijklmnopqrst***", NameFormatter.format("abcdefghijklmnopqrstu"));
  }
  @SuppressWarnings("static-access")
  @Test
  @DisplayName ("Testing class NameFormatter")
  void test2(){
	  NameFormatter one = new NameFormatter();
	  assertEquals("abcdefghijklmnopqrst***", one.format("abcdefghijklmnopqrstu"));
  }
  @Test
  @DisplayName ("Testing")
  void test3(){
	  assertThrows(IllegalArgumentException.class, () -> NameFormatter.format("@?#$%*fgh@dafaskdksndmajklmnopqrstu"));
  }
  
  @Test
  @DisplayName ("Greater than 30 and forbidden characters")
  void test4(){
	  assertThrows(IllegalArgumentException.class, () -> NameFormatter.format("@dddddddddddddddddddddddddddddddddd"));
  }
  @Test
  @DisplayName ("Testing string with length 3 with invalid character")
  void test5(){
       assertThrows(IllegalArgumentException.class, () -> NameFormatter.format("@sd"));
  }
}

