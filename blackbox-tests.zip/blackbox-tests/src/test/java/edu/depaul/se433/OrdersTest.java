package edu.depaul.se433;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import edu.depaul.se433.Orders.ShippingMethod;
//import static edu.depaul.se433.OrdersTest.ShippingMethod.*; 
//import edu.depaul.se433.mocks.FileService;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.fail;

public class OrdersTest {
  @Test
  @DisplayName("Test standard shipping when cost equals 50 and state is IL")
  void test() {
	  double result = Orders.calculateTotal(50.0, ShippingMethod.Standard, "IL");
	  assertEquals(53.0, result);
  }	
  @Test
  @DisplayName("Test standard shipping when cost less than 50")
  void test1() {
	  double result = Orders.calculateTotal(45.0, ShippingMethod.Standard, "AL");
	  assertEquals(55.0, result);
  }	
  @Test
  @DisplayName("Test standard shipping when cost greater than 50")
  void test2() {
	  double result = Orders.calculateTotal(55.0, ShippingMethod.Standard, "AL");
	  assertEquals(55.0, result);
  }	
  @Test
  @DisplayName("Test next day shipping when cost less than than 50")
  void test3() {
	  double result = Orders.calculateTotal(45.0, ShippingMethod.NextDay, "MI");
	  assertEquals(70.0, result);
  }	
  @Test
  @DisplayName("Test next day shipping when cost greater than than 50")
  void test4() {
	  double result = Orders.calculateTotal(55.0, ShippingMethod.NextDay, "MI");
	  assertEquals(80.0, result);
  }	
  @Test
  @DisplayName("Test the sales tax and shipping method when total cost is 0")
  void test5() {
	  assertThrows(IllegalArgumentException.class, () -> Orders.calculateTotal(0.0, ShippingMethod.Standard, "Illinois"));
  }
  @Test
  @DisplayName("Test standard shipping when total cost is 1")
  void test6() {
	  double result = Orders.calculateTotal(1.0, ShippingMethod.Standard, "MI");
	  assertEquals(11.0, result);
  }
  @Test
  @DisplayName("Test next day shipping when total cost is 1")
  void test7() {
	  double result = Orders.calculateTotal(1.0, ShippingMethod.NextDay, "MI");
	  assertEquals(26.0, result);
  }
  @Test
  @DisplayName("Test boundary when cost is 49.99 on standard shipping")
  void test8() {
	  double result = Orders.calculateTotal(49.99, ShippingMethod.Standard, "MI");
	  assertEquals(59.99, result);
  }
  @Test
  @DisplayName("Test boundary when cost is 50.01 on standard shipping")
  void test9() {
	  double result = Orders.calculateTotal(50.01, ShippingMethod.Standard, "MI");
	  assertEquals(50.01, result);
  }
  
  @Test
  @DisplayName("Test next day shipping when total cost is 50")
  void test10() {
	  double result = Orders.calculateTotal(50.0, ShippingMethod.NextDay, "Alabama");
	  assertEquals(75.0, result);
  }	
  @Test
  @DisplayName("test standard shipping when total cost is 50")
  void test11() {
	  double result = Orders.calculateTotal(50.0, ShippingMethod.Standard, "Alabama");
	  assertEquals(50.0, result);
  }	
  @Test
  @DisplayName("Test standard shipping when total cost is 0")
  void test12() {
	  assertThrows(IllegalArgumentException.class, () -> Orders.calculateTotal(0.0, ShippingMethod.Standard, "Ohio"));
  }	
  @Test
  @DisplayName("test standard shipping when shipping is out of country")
  void test13() {
	  double result = Orders.calculateTotal(10.0, ShippingMethod.Standard, "London");
	  //assertEquals(20.0, result);
	  fail("Incorrect Shipping State");
  }
  @Test
  @DisplayName("Test standard shipping when cost equals 50 and state is Illinois")
  void test14() {
	  double result = Orders.calculateTotal(50.0, ShippingMethod.Standard, "Illinios");
	  assertEquals(53.0, result);
  }	
  @Test
  @DisplayName("Test standard shipping when cost equals 50 and state is California")
  void test15() {
	  double result = Orders.calculateTotal(50.0, ShippingMethod.Standard, "California");
	  assertEquals(53.0, result);
  }	
  @Test
  @DisplayName("Test standard shipping when cost equals 50 and state is New York")
  void test16() {
	  double result = Orders.calculateTotal(50.0, ShippingMethod.Standard, "New York");
	  assertEquals(53.0, result);
  }	
  @Test
  @DisplayName("Test standard shipping when cost equals 50 and state is CA")
  void test17() {
	  double result = Orders.calculateTotal(50.0, ShippingMethod.Standard, "CA");
	  assertEquals(53.0, result);
  }	
  @Test
  @DisplayName("Test standard shipping when cost equals 50 and state is NY")
  void test18() {
	  double result = Orders.calculateTotal(50.0, ShippingMethod.Standard, "NY");
	  assertEquals(53.0, result);
  }
  @SuppressWarnings("static-access")
  @Test
  @DisplayName("Test standard shipping when cost equals 50 and state is NY")
  void test19() {
	  Orders one = new Orders();
	  assertEquals(53.0, one.calculateTotal(50.0, ShippingMethod.Standard, "NY"));
  }
}