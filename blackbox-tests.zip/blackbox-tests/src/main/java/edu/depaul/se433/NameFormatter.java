package edu.depaul.se433;

public class NameFormatter {
    private static final String ILLEGAL_CHARS = "@?#$%*";

  public static String format(String originalName) {
    if (originalName.length() < 2) {
      throw new IllegalArgumentException("name is too short");
    }

    if (originalName.length() > 30) {
      throw new IllegalArgumentException("name is too long");
    }

    if ((originalName.length() > 30) && containsForbiddenChars(originalName)) {
      throw new IllegalArgumentException("Multiple problems found");
    }

    if (originalName.length() > 20) {
      return originalName.substring(0, 20) + "***";
    } else {
      return originalName;
    }
  }

  private static boolean containsForbiddenChars(String name) {
    for (int i = 0; i < ILLEGAL_CHARS.length(); i++) {
      if (name.indexOf(ILLEGAL_CHARS.charAt(i)) > -1) {
        return true;
      }
    }
    return false;
  }
}
